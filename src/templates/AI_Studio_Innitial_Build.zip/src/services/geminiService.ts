import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export async function convertTask(sourcePlatform: string, targetPlatform: string, taskDetails: string) {
  const prompt = `
    I have a scheduled task on ${sourcePlatform} and I want to convert it to ${targetPlatform}.
    
    Task Details:
    ${taskDetails}
    
    Please provide the equivalent configuration or command for ${targetPlatform}. 
    Include instructions if manual setup is needed. 
    Format the response in Markdown.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text || "No transformation generated.";
  } catch (error) {
    console.error("Conversion failed", error);
    throw error;
  }
}
