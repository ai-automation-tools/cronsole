import React, { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  Timestamp,
  orderBy
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Task, Platform } from '../types';
import { Plus, Trash2, Pause, Play, Edit3, Loader2, Calendar, Layout, Terminal, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export function MyTasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'tasks'),
      where('userId', '==', auth.currentUser.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const taskList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Task[];
      setTasks(taskList);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching tasks:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const toggleStatus = async (task: Task) => {
    if (!task.id) return;
    const nextStatus = task.status === 'active' ? 'paused' : 'active';
    try {
      await updateDoc(doc(db, 'tasks', task.id), {
        status: nextStatus,
        updatedAt: Timestamp.now()
      });
    } catch (err) {
      console.error("Failed to update status", err);
    }
  };

  const deleteTask = async (id: string) => {
    if (!confirm("Are you sure you want to delete this task?")) return;
    try {
      await deleteDoc(doc(db, 'tasks', id));
    } catch (err) {
      console.error("Failed to delete task", err);
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">My Scheduled Tasks</h1>
          <p className="text-muted-foreground">Manage your routines across all platforms.</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-primary rounded-lg font-medium hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
        >
          <Plus size={18} />
          <span>Add Task</span>
        </button>
      </header>

      {loading ? (
        <div className="h-64 flex items-center justify-center">
          <Loader2 className="animate-spin text-primary" size={32} />
        </div>
      ) : tasks.length === 0 ? (
        <div className="h-64 flex flex-col items-center justify-center border-2 border-dashed border-border rounded-2xl text-muted-foreground">
          <Calendar size={40} className="mb-4 opacity-50" />
          <p className="text-lg font-medium">No tasks found</p>
          <p className="text-sm">Click "Add Task" to start managing your schedules.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <AnimatePresence>
            {tasks.map((task) => (
              <motion.div
                key={task.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="group p-5 rounded-2xl bg-card border border-border hover:border-primary/50 transition-all shadow-sm"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center",
                      task.platform === 'Windows' ? 'bg-blue-500/10 text-blue-500' :
                      task.platform === 'Claude' ? 'bg-orange-500/10 text-orange-500' :
                      'bg-primary/10 text-primary'
                    )}>
                      <Layout size={20} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg leading-none">{task.name}</h3>
                      <span className="text-xs text-muted-foreground mt-1 block">{task.platform}</span>
                    </div>
                  </div>
                  <div className={cn(
                    "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                    task.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-secondary text-muted-foreground'
                  )}>
                    {task.status}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground bg-secondary/50 px-3 py-2 rounded-lg">
                    <Clock size={16} />
                    <span className="font-mono">{task.schedule}</span>
                  </div>
                  {task.command && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground bg-secondary/50 px-3 py-2 rounded-lg">
                      <Terminal size={16} />
                      <span className="truncate font-mono">{task.command}</span>
                    </div>
                  )}
                </div>

                <div className="mt-6 pt-4 border-t border-border flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleStatus(task)}
                      className="p-2 hover:bg-secondary rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                      title={task.status === 'active' ? 'Pause' : 'Activate'}
                    >
                      {task.status === 'active' ? <Pause size={18} /> : <Play size={18} />}
                    </button>
                    <button
                      className="p-2 hover:bg-secondary rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                      title="Edit"
                    >
                      <Edit3 size={18} />
                    </button>
                  </div>
                  <button
                    onClick={() => task.id && deleteTask(task.id)}
                    className="p-2 hover:bg-red-500/10 rounded-lg text-muted-foreground hover:text-red-500 transition-colors"
                    title="Delete"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {showAddModal && (
        <AddTaskModal 
          onClose={() => setShowAddModal(false)} 
          onAdd={async (newTask) => {
            try {
              await addDoc(collection(db, 'tasks'), {
                ...newTask,
                userId: auth.currentUser?.uid,
                createdAt: Timestamp.now(),
                updatedAt: Timestamp.now()
              });
              setShowAddModal(false);
            } catch (err) {
              console.error("Failed to add task", err);
            }
          }}
        />
      )}
    </div>
  );
}

function AddTaskModal({ onClose, onAdd }: { onClose: () => void, onAdd: (task: Partial<Task>) => void }) {
  const [formData, setFormData] = useState({
    name: '',
    platform: 'Windows' as Platform,
    schedule: '* * * * *',
    command: '',
    status: 'active' as const
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-card border border-border w-full max-w-lg rounded-3xl p-8 shadow-2xl"
      >
        <h2 className="text-2xl font-bold mb-6">Create New Task</h2>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Task Name</label>
            <input 
              type="text" 
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              placeholder="Morning Report Sync"
              className="w-full bg-secondary border border-border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Platform</label>
              <select 
                value={formData.platform}
                onChange={(e) => setFormData({...formData, platform: e.target.value as Platform})}
                className="w-full bg-secondary border border-border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary"
              >
                {['Windows', 'Claude', 'ChatGPT', 'Jules', 'Other'].map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Schedule (Cron)</label>
              <input 
                type="text" 
                value={formData.schedule}
                onChange={(e) => setFormData({...formData, schedule: e.target.value})}
                placeholder="0 9 * * *"
                className="w-full bg-secondary border border-border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary font-mono"
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Command / Script</label>
            <textarea 
              value={formData.command}
              onChange={(e) => setFormData({...formData, command: e.target.value})}
              placeholder="python script.py --args"
              className="w-full bg-secondary border border-border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-primary h-24 resize-none font-mono"
            />
          </div>
        </div>
        <div className="flex gap-4 mt-8">
          <button 
            onClick={onClose}
            className="flex-1 py-3 border border-border rounded-xl font-medium hover:bg-secondary transition-colors"
          >
            Cancel
          </button>
          <button 
            disabled={!formData.name}
            onClick={() => onAdd(formData)}
            className="flex-1 py-3 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-colors disabled:opacity-50"
          >
            Create Task
          </button>
        </div>
      </motion.div>
    </div>
  );
}
