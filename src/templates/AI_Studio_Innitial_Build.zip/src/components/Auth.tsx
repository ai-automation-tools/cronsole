import React from 'react';
import { signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { LogIn, LogOut } from 'lucide-react';
import { motion } from 'motion/react';

export function LoginButton() {
  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login failed', error);
    }
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={handleLogin}
      className="flex items-center gap-2 px-4 py-2 bg-primary rounded-lg font-medium hover:bg-primary/90 transition-colors"
    >
      <LogIn size={18} />
      <span>Sign in with Google</span>
    </motion.button>
  );
}

export function LogoutButton() {
  const handleLogout = () => signOut(auth);

  return (
    <button
      onClick={handleLogout}
      className="flex items-center gap-2 px-4 py-2 text-muted-foreground hover:text-foreground transition-colors"
    >
      <LogOut size={18} />
      <span>Sign Out</span>
    </button>
  );
}
