# System Architecture

OmniTask is a modern full-stack web application built with a serverless architecture.

## Frontend
The UI is built with **React** and **Tailwind CSS**. It uses a single-page application (SPA) model where the state is managed via React hooks and Firebase's real-time listeners.

### Key Components:
- **`App.tsx`**: The main orchestrator handling authentication states and view switching.
- **`Sidebar.tsx`**: Navigation and quick links to external platforms (Claude, GPT, Jules).
- **`MyTasks.tsx`**: Real-time task management interface using Firestore `onSnapshot`.
- **`TaskConverter.tsx`**: The AI-powered tool for transforming configurations between platforms.

## Backend Features
We leverage **Firebase** for backend services:
- **Authentication**: Google OAuth via Firebase Auth.
- **Persistence**: Firestore NoSQL database for tasks and user profiles.
- **API Proxy**: Environment variables for Gemini AI are handled via Vite's build-time injection for the client-side SDK.

## Data Flow
1. **User Auth**: User logs in -> UID obtained -> Firestore query filtered by `userId`.
2. **Task Creation**: UI form -> `addDoc` to Firestore -> Security rules validate schema and ownership.
3. **Task Conversion**: Source config -> Gemini API -> AI analysis -> Suggested Target config.
