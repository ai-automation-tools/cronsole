import React, { useState } from 'react';
import { RefreshCcw, ArrowRight, Loader2, Copy, Check } from 'lucide-react';
import { convertTask } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';

const PLATFORMS = ['Windows Task Scheduler', 'Claude Routines', 'ChatGPT Automations', 'Jules', 'Crontab', 'Other'];

export function TaskConverter() {
  const [source, setSource] = useState(PLATFORMS[0]);
  const [target, setTarget] = useState(PLATFORMS[1]);
  const [details, setDetails] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleConvert = async () => {
    if (!details.trim()) return;
    setLoading(true);
    try {
      const output = await convertTask(source, target, details);
      setResult(output);
    } catch (error) {
      setResult("Error: Failed to convert task. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header>
        <h1 className="text-3xl font-bold">AI Task Converter</h1>
        <p className="text-muted-foreground mt-1">Convert scheduling configurations between platforms instantly.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="flex-1 space-y-2">
              <label className="text-sm font-medium text-muted-foreground">From</label>
              <select 
                value={source}
                onChange={(e) => setSource(e.target.value)}
                className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-foreground focus:ring-2 focus:ring-primary outline-none"
              >
                {PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div className="mt-6">
              <ArrowRight size={20} className="text-muted-foreground" />
            </div>
            <div className="flex-1 space-y-2">
              <label className="text-sm font-medium text-muted-foreground">To</label>
              <select 
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-foreground focus:ring-2 focus:ring-primary outline-none"
              >
                {PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Task Details / Config</label>
            <textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="Paste your source configuration here (e.g., XML from Windows, Cron string, or description)..."
              className="w-full h-64 bg-secondary border border-border rounded-xl p-4 text-foreground font-mono text-sm focus:ring-2 focus:ring-primary outline-none resize-none"
            />
          </div>

          <button
            onClick={handleConvert}
            disabled={loading || !details.trim()}
            className="w-full py-3 bg-primary text-white rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-primary/20"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <RefreshCcw size={20} />}
            <span>Convert with Gemini</span>
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Result</h3>
            {result && !loading && (
              <button 
                onClick={copyToClipboard}
                className="text-xs flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            )}
          </div>
          
          <div className="bg-secondary/30 border border-border rounded-xl h-[524px] overflow-auto p-4 relative">
            <AnimatePresence mode="wait">
              {loading ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground"
                >
                  <Loader2 className="animate-spin mb-2" size={32} />
                  <p>Analyzing and translating...</p>
                </motion.div>
              ) : result ? (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="prose prose-invert prose-sm max-w-none"
                >
                  <ReactMarkdown>{result}</ReactMarkdown>
                </motion.div>
              ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground text-sm italic text-center px-8">
                  Generated configuration will appear here.
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
