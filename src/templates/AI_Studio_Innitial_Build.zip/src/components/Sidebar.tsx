import React from 'react';
import { 
  LayoutDashboard, 
  ListTodo, 
  Layers, 
  RefreshCcw, 
  ExternalLink,
  Settings,
  Plus
} from 'lucide-react';
import { cn } from '../lib/utils';

export type AppView = 'dashboard' | 'tasks' | 'templates' | 'converter';

interface SidebarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
}

export function Sidebar({ currentView, setView }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tasks', label: 'My Tasks', icon: ListTodo },
    { id: 'templates', label: 'Templates', icon: Layers },
    { id: 'converter', label: 'AI Converter', icon: RefreshCcw },
  ];

  return (
    <aside className="w-64 border-r border-border h-screen bg-card p-4 flex flex-col gap-8">
      <div className="flex items-center gap-2 px-2">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
          <RefreshCcw className="text-white" size={20} />
        </div>
        <h1 className="text-xl font-bold tracking-tight">OmniTask</h1>
      </div>

      <nav className="flex-1 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as AppView)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors group",
              currentView === item.id 
                ? "bg-primary/10 text-primary" 
                : "text-muted-foreground hover:bg-accent hover:text-foreground"
            )}
          >
            <item.icon size={20} />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="mt-auto space-y-1">
        <h3 className="px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground/60 mb-2">
          System Links
        </h3>
        <a 
          href="https://claude.ai/code/routines" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center justify-between px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors group"
        >
          <span>Claude Routines</span>
          <ExternalLink size={14} className="opacity-0 group-hover:opacity-100" />
        </a>
        <a 
          href="https://chatgpt.com/schedules" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center justify-between px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors group"
        >
          <span>GPT Automations</span>
          <ExternalLink size={14} className="opacity-0 group-hover:opacity-100" />
        </a>
        <a 
          href="https://jules.google.com/session" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center justify-between px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors group"
        >
          <span>Jules Schedules</span>
          <ExternalLink size={14} className="opacity-0 group-hover:opacity-100" />
        </a>
      </div>
    </aside>
  );
}
