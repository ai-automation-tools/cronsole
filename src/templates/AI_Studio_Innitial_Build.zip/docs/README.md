# OmniTask Technical Documentation

Welcome to the technical documentation for OmniTask, a centralized hub for managing scheduled tasks across Windows, AI platforms, and automation tools.

## Table of Contents
1. [Architecture Overview](./architecture.md)
2. [Database & Security](./database.md)
3. [AI Integration](./ai-integration.md)
4. [User Guide](./how-to-use.md)

## Project Vision
OmniTask aims to solve the fragmentation of "distributed cron jobs." By providing a single interface for Windows Task Scheduler, Claude Routines, GPT Automations, and more, users can monitor and convert their schedules seamlessly.

## Tech Stack
- **Frontend**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS 4.0
- **Database/Auth**: Firebase (Firestore & Auth)
- **AI Engine**: Gemini AI (via `@google/genai`)
- **Animations**: Motion (formerly Framer Motion)
