import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './lib/firebase';
import { Sidebar, AppView } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { MyTasks } from './components/MyTasks';
import { TaskConverter } from './components/TaskConverter';
import { LoginButton, LogoutButton } from './components/Auth';
import { motion, AnimatePresence } from 'motion/react';
import { Loader2, Zap } from 'lucide-react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from './lib/firebase';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<AppView>('dashboard');
  const [taskCount, setTaskCount] = useState(0);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'tasks'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setTaskCount(snapshot.size);
    });
    return () => unsubscribe();
  }, [user]);

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="animate-spin text-primary" size={40} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-background p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-6 max-w-md"
        >
          <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mx-auto mb-8 ring-4 ring-primary/5">
            <Zap className="text-primary" size={48} />
          </div>
          <h1 className="text-5xl font-bold tracking-tight">OmniTask</h1>
          <p className="text-muted-foreground text-lg italic">
            "One scheduler to rule them all. Across Windows, AI, and the cloud."
          </p>
          <div className="pt-8">
            <LoginButton />
          </div>
          <div className="pt-12 grid grid-cols-2 gap-4 opacity-50 text-xs uppercase font-bold tracking-widest">
            <div className="p-3 border border-dashed border-border rounded-xl">Windows Tasker</div>
            <div className="p-3 border border-dashed border-border rounded-xl">AI Routines</div>
            <div className="p-3 border border-dashed border-border rounded-xl">Cloud Cron</div>
            <div className="p-3 border border-dashed border-border rounded-xl">Hermes Sync</div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar currentView={view} setView={setView} />
      
      <main className="flex-1 overflow-auto relative">
        <header className="h-16 border-b border-border px-8 flex items-center justify-between sticky top-0 bg-background/80 backdrop-blur-md z-10">
          <div className="text-sm font-medium text-muted-foreground capitalize">
            {view === 'dashboard' ? 'Overview' : view}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-end">
              <span className="text-sm font-medium">{user.displayName || 'User'}</span>
              <span className="text-[10px] text-muted-foreground">{user.email}</span>
            </div>
            <LogoutButton />
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {view === 'dashboard' && <Dashboard setView={setView} taskCount={taskCount} />}
              {view === 'tasks' && <MyTasks />}
              {view === 'converter' && <TaskConverter />}
              {view === 'templates' && (
                <div className="h-64 flex flex-col items-center justify-center border-2 border-dashed border-border rounded-3xl text-muted-foreground">
                  <span className="text-3xl mb-2">🏗️</span>
                  <p className="font-medium text-lg">Template Center Coming Soon</p>
                  <p className="text-sm">We're loading up high-quality samples from the community.</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
