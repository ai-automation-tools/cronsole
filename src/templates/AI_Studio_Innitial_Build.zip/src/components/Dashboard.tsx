import React from 'react';
import { motion } from 'motion/react';
import { 
  Plus, 
  Activity, 
  Clock, 
  CheckCircle2, 
  AlertCircle
} from 'lucide-react';
import { AppView } from './Sidebar';

interface DashboardProps {
  setView: (view: AppView) => void;
  taskCount: number;
}

export function Dashboard({ setView, taskCount }: DashboardProps) {
  const stats = [
    { label: 'Total Tasks', value: taskCount, icon: Activity, color: 'text-primary' },
    { label: 'Active', value: taskCount, icon: CheckCircle2, color: 'text-emerald-500' },
    { label: 'Scheduled Today', value: 0, icon: Clock, color: 'text-amber-500' },
    { label: 'Issues', value: 0, icon: AlertCircle, color: 'text-red-500' },
  ];

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Welcome back</h1>
          <p className="text-muted-foreground">Here's what's happening with your scheduled tasks.</p>
        </div>
        <button
          onClick={() => setView('tasks')}
          className="flex items-center gap-2 px-4 py-2 bg-primary rounded-lg font-medium shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all hover:translate-y-[-1px]"
        >
          <Plus size={18} />
          <span>New Task</span>
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-6 rounded-2xl bg-card border border-border"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-2 rounded-lg bg-secondary ${stat.color}`}>
                <stat.icon size={20} />
              </div>
            </div>
            <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
            <h3 className="text-2xl font-bold">{stat.value}</h3>
          </motion.div>
        ))}
      </div>

      <section>
        <h2 className="text-xl font-semibold mb-4">Quick Shortcuts</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <ShortcutCard 
            title="Convert Task" 
            desc="Move tasks between platforms using Gemini AI."
            onClick={() => setView('converter')}
          />
          <ShortcutCard 
            title="Browse Templates" 
            desc="Find pre-configured tasks for Windows, Claude, and more."
            onClick={() => setView('templates')}
          />
          <ShortcutCard 
            title="System Monitor" 
            desc="Check real-time health of your distributed cron jobs."
            disabled
          />
        </div>
      </section>
    </div>
  );
}

function ShortcutCard({ title, desc, onClick, disabled }: { title: string, desc: string, onClick?: () => void, disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "p-6 rounded-2xl border border-border text-left transition-all group",
        disabled ? "opacity-50 cursor-not-allowed" : "bg-card hover:bg-accent hover:border-primary/50"
      )}
    >
      <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">{title}</h3>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </button>
  );
}

import { cn } from '../lib/utils';
