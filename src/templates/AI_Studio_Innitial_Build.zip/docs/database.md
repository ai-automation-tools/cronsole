# Database & Security Schema

OmniTask uses Firestore Enterprise for real-time data synchronization.

## Firestore Collections

### 1. `tasks`
The primary collection for all scheduled tasks.
- **`userId`** (string): The UID of the owner.
- **`name`** (string): Task display name.
- **`platform`** (string): Origin platform (Windows, Claude, etc.).
- **`schedule`** (string): Cron expression or human-readable schedule.
- **`command`** (string): The script or command being run.
- **`status`** (enum): `active`, `paused`, or `failed`.
- **`isTemplate`** (boolean): If true, visible to everyone.
- **`createdAt/updatedAt`** (Timestamp): Server-side tracking.

### 2. `users`
Private user profiles.
- **`name`**, **`email`**: User identity data.
- **`isAdmin`**: Reserved for system-level overrides.

## Security Rules (`firestore.rules`)
Our rules follow the **Eight Pillars of Hardened Rules**:
- **Identity Integrity**: Users can only write data where `userId == request.auth.uid`.
- **Schema Validation**: Every write is checked against `isValidTask` which enforces types and string sizes.
- **Immutable Fields**: `createdAt` and `userId` cannot be changed after creation.
- **Default Deny**: All paths are closed unless explicitly opened by a match block.
