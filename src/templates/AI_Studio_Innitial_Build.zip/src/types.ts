import { Timestamp } from 'firebase/firestore';

export type Platform = 'Windows' | 'Claude' | 'ChatGPT' | 'Jules' | 'Hermes' | 'OpenClaw' | 'Manual' | 'Other';

export interface Task {
  id?: string;
  userId: string;
  name: string;
  platform: Platform;
  schedule: string;
  command: string;
  status: 'active' | 'paused' | 'failed';
  lastRun?: Timestamp | null;
  isTemplate?: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface UserProfile {
  name: string;
  email: string;
  isAdmin?: boolean;
}
