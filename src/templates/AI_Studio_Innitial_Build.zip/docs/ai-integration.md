# Gemini AI Integration

OmniTask uses the **Gemini 3 Flash Preview** model to power its intelligent features.

## Task Conversion Logic
The conversion service is located in `src/services/geminiService.ts`. 

### The Process:
1. The user selects a **Source Platform** (e.g., Windows Task Scheduler) and a **Target Platform** (e.g., Claude Routines).
2. The user pastes their configuration (XML, JSON, or raw description).
3. The app sends a prompt to Gemini asking it to "Translate this configuration for the target system."
4. Gemini returns a Markdown-formatted response containing the new settings and manual setup steps.

## AI Grounding
Future versions will include MCP (Model Context Protocol) support to allow external AI models to directly read and create tasks in OmniTask using standardized endpoints.
