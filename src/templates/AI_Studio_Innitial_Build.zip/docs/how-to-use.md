# User Guide

OmniTask is designed to be your central mission control for automation.

## 1. Connecting Your Account
When you first open the app, click **"Sign in with Google"**. This creates your private encrypted workspace in our Firestore database.

## 2. Managing Tasks
- **Add a Task**: Click the "+ Add Task" button. You can store your schedule (Cron format like `0 * * * *`) and the command you're running. Note: OmniTask currently acts as a *manager* and *monitor*. It does not execute local Windows scripts directly—it helps you keep track of where they are running.
- **Status Toggles**: Use the Play/Pause icons to track which scripts are currently enabled on your local machines or platforms.

## 3. Using the AI Converter
If you have a complex Windows Task Scheduler XML and want to move it to a 24/7 cloud environment or an AI routine:
1. Go to the **AI Converter** tab.
2. Paste the source configuration.
3. Select your destination platform.
4. Let Gemini generate the equivalent setup instructions for you.

## 4. Platform Shortcuts
The sidebar contains quick links to:
- **Claude Routines**: For your AI-native scheduled workflows.
- **GPT Automations**: For OpenAI's scheduled tasks.
- **Jules & Hermes**: For your Google-based and distributed automation sessions.
